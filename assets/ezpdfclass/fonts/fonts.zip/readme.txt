install ttf

copy the true type font to this folder
c:\programfiles\gnuwin32\bin

ttf2pt1 -b filename of font 

conver to afm, pfb, ttf.

copy all this to ezpdfclass to fonts folder




